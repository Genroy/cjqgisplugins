def classFactory(iface):
    from .Clickpointtoedit import Clickpointtoedit
    return Clickpointtoedit(iface)

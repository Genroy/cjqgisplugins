# -*- coding: utf-8 -*-
"""
Streetview_qgis_cej - QGIS plugin (clean rebuild with SVG marker rotation+zoom)
"""
import os
from qgis.PyQt import QtWidgets, QtWebEngineWidgets, QtCore
from qgis.gui import QgsMapToolEmitPoint
from qgis.core import (
    QgsProject, QgsCoordinateReferenceSystem, QgsCoordinateTransform,
    QgsMessageLog, Qgis, QgsPointXY, QgsVectorLayer, QgsFeature, QgsGeometry,
    QgsSingleSymbolRenderer, QgsMarkerSymbol, QgsProperty, QgsSvgMarkerSymbolLayer, QgsSymbolLayer
)
from PyQt5.QtWebChannel import QWebChannel
from PyQt5.QtCore import QObject, pyqtSlot

def log(msg, level=Qgis.Info):
    QgsMessageLog.logMessage(str(msg), "StreetView", level)

class StreetViewBridge(QObject):
    def __init__(self, plugin_ref):
        super().__init__()
        self.plugin_ref = plugin_ref

    @pyqtSlot(float, float)
    def updatePosition(self, lat, lon):
        try:
            self.plugin_ref.update_marker_position_from_wgs(lat, lon)
        except Exception as e:
            log(f"updatePosition error: {e}", Qgis.Warning)

    @pyqtSlot(float, float, float)
    def updateCamera(self, heading, pitch, zoom):
        try:
            self.plugin_ref.update_marker_heading(heading, pitch, zoom)
        except Exception as e:
            log(f"updateCamera error: {e}", Qgis.Warning)

class StreetViewDockWidget(QtWidgets.QDockWidget):
    def __init__(self, iface, api_key):
        super().__init__("Street View (Interactive)")
        self.iface = iface
        self.api_key = api_key

        # state
        self.heading = 0.0
        self.pitch = 0.0
        self.zoom = 1.0

        # ---- UI ----
        wrap = QtWidgets.QWidget()
        self.setWidget(wrap)
        v = QtWidgets.QVBoxLayout(wrap)

        bar = QtWidgets.QHBoxLayout()
        self.pickBtn = QtWidgets.QPushButton("Pick on map")
        self.followChk = QtWidgets.QCheckBox("Follow camera (rotate)")
        self.followChk.setChecked(True)
        bar.addWidget(self.pickBtn)
        bar.addWidget(self.followChk)
        bar.addStretch(1)
        v.addLayout(bar)

        self.webview = QtWebEngineWidgets.QWebEngineView()
        v.addWidget(self.webview, 1)

        self.statusLbl = QtWidgets.QLabel("Ready")
        v.addWidget(self.statusLbl)

        # Initial
        self.webview.setHtml(
            "<html><body style='text-align:center;background:#f5f5f5'><h3>คลิกแผนที่เพื่อเริ่ม Street View</h3></body></html>"
        )

        # ---- WebChannel ----
        self.channel = QWebChannel()
        self.bridge = StreetViewBridge(self)
        self.channel.registerObject("bridge", self.bridge)
        self.webview.page().setWebChannel(self.channel)

        # ---- Map tool ----
        self.map_tool = QgsMapToolEmitPoint(iface.mapCanvas())
        self.map_tool.canvasClicked.connect(self.on_canvas_clicked)
        self.pickBtn.clicked.connect(self.activate_map_tool)

        # ---- Rotatable SVG marker layer ----
        self.point_layer = None
        self.point_fid = None
        self.ensure_point_layer()

        iface.addDockWidget(QtCore.Qt.RightDockWidgetArea, self)

    # ---------- Marker memory layer ----------
    def ensure_point_layer(self):
        canvas_crs = self.iface.mapCanvas().mapSettings().destinationCrs().authid()
        vl_def = f"Point?crs={canvas_crs}&field=heading:double&field=pitch:double&field=zoom:double"
        self.point_layer = QgsVectorLayer(vl_def, "SV Marker (temp)", "memory")

        svg_path = os.path.join(os.path.dirname(__file__), "arrow.svg")
        svg_layer = QgsSvgMarkerSymbolLayer(svg_path, 8.0, 0.0)
        svg_layer.setDataDefinedProperty(QgsSymbolLayer.PropertyAngle, QgsProperty.fromExpression('"heading"'))
        svg_layer.setDataDefinedProperty(QgsSymbolLayer.PropertySize, QgsProperty.fromExpression('8 + 3 * "zoom"'))
        symbol = QgsMarkerSymbol()
        symbol.changeSymbolLayer(0, svg_layer)
        self.point_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

        QgsProject.instance().addMapLayer(self.point_layer, addToLegend=True)

        feat = QgsFeature(self.point_layer.fields())
        feat.setGeometry(QgsGeometry())
        feat['heading'] = 0.0
        feat['pitch'] = 0.0
        feat['zoom'] = 1.0
        self.point_layer.dataProvider().addFeatures([feat])
        self.point_layer.updateExtents()

        # bring to top
        try:
            lt = QgsProject.instance().layerTreeRoot()
            node = lt.findLayer(self.point_layer.id())
            if node:
                lt.insertChildNode(0, node.clone())
                lt.removeChildNode(node)
        except Exception:
            pass

        self.point_fid = next(self.point_layer.getFeatures()).id()

    def set_marker_canvas_point(self, point_canvas):
        if not self.point_layer or self.point_fid is None:
            return
        pr = self.point_layer.dataProvider()
        pr.changeGeometryValues({self.point_fid: QgsGeometry.fromPointXY(point_canvas)})

    def set_marker_heading_pitch_zoom(self, heading, pitch, zoom):
        if not self.point_layer or self.point_fid is None:
            return
        pr = self.point_layer.dataProvider()
        pr.changeAttributeValues({
            self.point_fid: {
                self.point_layer.fields().indexOf('heading'): float(heading),
                self.point_layer.fields().indexOf('pitch'): float(pitch),
                self.point_layer.fields().indexOf('zoom'): float(zoom),
            }
        })
        self.point_layer.triggerRepaint()

    # ---------- Map interactions ----------
    def activate_map_tool(self):
        self.iface.mapCanvas().setMapTool(self.map_tool)
        self.statusLbl.setText("Click on map to open Street View…")

    def on_canvas_clicked(self, point, button):
        canvas = self.iface.mapCanvas()
        crs_src = canvas.mapSettings().destinationCrs()
        crs_wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        to_wgs84 = QgsCoordinateTransform(crs_src, crs_wgs84, QgsProject.instance())

        wgs_point = to_wgs84.transform(point)
        lat, lon = wgs_point.y(), wgs_point.x()

        self.set_marker_canvas_point(point)
        self.load_street_view_html(lat, lon, self.heading)
        log(f"Point clicked at: ")
        log("HTML Loaded OK", Qgis.Info)
        log(f"Lat: {lat}, Lon: {lon}, Heading: {self.heading}", Qgis.Info)
        log("Street View loaded in webview.")

    # ---------- JS ↔ Python helpers ----------
    def load_street_view_html(self, lat, lon, heading_deg):
        tpl_path = os.path.join(os.path.dirname(__file__), "streetview_template.html")
        with open(tpl_path, "r", encoding="utf-8") as f:
            html = f.read()
        html = (html.replace("{lat}", str(lat))
                    .replace("{lon}", str(lon))
                    .replace("{heading}", str(float(heading_deg)))
                    .replace("{api_key}", self.api_key))
        self.webview.setHtml(html)

    def update_marker_position_from_wgs(self, lat, lon):
        canvas = self.iface.mapCanvas()
        crs_dst = canvas.mapSettings().destinationCrs()
        crs_wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        tr = QgsCoordinateTransform(crs_wgs84, crs_dst, QgsProject.instance())
        pt_canvas = tr.transform(QgsPointXY(lon, lat))
        self.set_marker_canvas_point(pt_canvas)

    def update_marker_heading(self, heading, pitch, zoom):
        self.heading = float(heading)
        self.pitch = float(pitch)
        self.zoom = float(zoom)
        # always update
        self.set_marker_heading_pitch_zoom(self.heading, self.pitch, self.zoom)
        self.statusLbl.setText(f"Camera: heading {self.heading:.1f}°, pitch {self.pitch:.1f}°, zoom {self.zoom:.1f}")

class StreetViewQGISCej:
    def __init__(self, iface):
        self.iface = iface
        self.widget = None
        self.action = None

    def initGui(self):
        self.action = QtWidgets.QAction("OpenStreetView", self.iface.mainWindow())
        self.action.triggered.connect(self.open_street_view)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Street View Plugin", self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu("&Street View Plugin", self.action)
            self.iface.removeToolBarIcon(self.action)
        if self.widget:
            self.iface.removeDockWidget(self.widget)
            self.widget = None

    def open_street_view(self):
        if not self.widget:
            api_key = 'AIzaSyB3CBkQPkDRSbSRZEw4yozTvtDnusVyIJM'
            self.widget = StreetViewDockWidget(self.iface, api_key)
        self.widget.show()
        self.widget.activate_map_tool()

def classFactory(iface):
    from .Blocklop import BlocklopPickTool
    return BlocklopPickTool(iface)
